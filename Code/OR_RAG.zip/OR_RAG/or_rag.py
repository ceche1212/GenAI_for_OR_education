import os
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import Chroma
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA

# --- 1. Environment Setup ---
# Load environment variables from a .env file for security
load_dotenv()

# Define constants for file paths and model names
PDF_FILE_PATH = "source_document.pdf"
PERSIST_DIRECTORY = "./chroma_db_openai"
LLM_MODEL = "gpt-4o-mini" # here you specify the LLM model

# --- 2. Document Loading and Processing ---
def load_and_split_pdf(file_path):
    """
    Loads a PDF document and splits it into smaller chunks.
    This follows the 'Indexing' part of a typical RAG pipeline.
    """
    print(f"Loading and splitting document: {file_path}")
    
    # Load the document using PyPDFLoader
    loader = PyPDFLoader(file_path)
    documents = loader.load()
    
    # Split the document into smaller chunks for better retrieval
    # This is crucial for RAG as it helps find more specific context.
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    split_docs = text_splitter.split_documents(documents)
    
    print(f"Document split into {len(split_docs)} chunks.")
    return split_docs

# --- 3. Vector Store and Embeddings ---
def setup_vector_store(split_docs, persist_directory):
    """
    Creates or loads a Chroma vector store with OpenAI embeddings.
    Embeddings convert text chunks into numerical vectors.
    The vector store indexes these vectors for fast similarity search.
    """
    print("Setting up vector store...")
    
    # Initialize the embedding model from OpenAI
    embedding_model = OpenAIEmbeddings()
    
    # Check if the database directory already exists to avoid re-creating it
    if os.path.exists(persist_directory):
        print("Loading existing vector store from disk.")
        db = Chroma(persist_directory=persist_directory, embedding_function=embedding_model)
    else:
        print("Creating new vector store and persisting to disk.")
        db = Chroma.from_documents(
            documents=split_docs, 
            embedding=embedding_model, 
            persist_directory=persist_directory
        )
    return db

# --- 4. RAG Chain Creation ---
def create_rag_chain(db):
    """
    Creates the main RetrievalQA chain.
    This chain connects the retriever (vector store) and the language model.
    """
    print("Creating the RAG chain...")
    
    # Configure the retriever, which fetches relevant documents from the vector store
    # 'k=4' means it will retrieve the top 4 most relevant chunks.
    retriever = db.as_retriever(search_kwargs={'k': 4})

    # Initialize the language model we want to use for answering
    llm = ChatOpenAI(model_name=LLM_MODEL, temperature=0.1)

    # Define a prompt template to structure the input for the LLM
    # This guides the model to answer based *only* on the provided context.
    prompt_template = """
    Use the following pieces of context to answer the question at the end. 
    If you don't know the answer from the context, just say that you don't know. Don't try to make up an answer.
    Provide a detailed and helpful answer.

    Context:
    {context}

    Question: {question}
    
    Helpful Answer:
    """
    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context", "question"]
    )

    # Create the RetrievalQA chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff", # "stuff" puts all retrieved chunks into the context
        retriever=retriever,
        return_source_documents=True, # Optionally return the source chunks
        chain_type_kwargs={"prompt": PROMPT}
    )
    
    print("RAG chain created successfully.")
    return qa_chain

# --- 5. Main Execution Block ---
def main():
    """
    Main function to run the entire RAG pipeline.
    """
    # First, check if the vector database already exists.
    if not os.path.exists(PERSIST_DIRECTORY):
        # If not, we need to process the PDF first.
        if not os.path.exists(PDF_FILE_PATH):
            print(f"Error: The file '{PDF_FILE_PATH}' was not found.")
            print("Please add your PDF to the directory and update the file path.")
            return

        # Load and split the PDF
        split_docs = load_and_split_pdf(PDF_FILE_PATH)
        # Create the vector store (this will be done only once)
        db = setup_vector_store(split_docs, PERSIST_DIRECTORY)
    else:
        # If the database exists, just load it
        db = setup_vector_store(None, PERSIST_DIRECTORY)

    # Create the RAG chain
    qa_chain = create_rag_chain(db)
    
    # Start an interactive loop to ask questions
    print("\n--- Ready to answer your questions! ---")
    print("Type 'exit' to quit.")
    
    while True:
        query = input("\nPlease ask a question about the document: ")
        if query.lower() == 'exit':
            break
        
        # Invoke the chain with the user's query
        result = qa_chain.invoke({"query": query})
        
        # Print the final answer
        print("\nAnswer:")
        print(result['result'])

        # Optionally, print the sources it used to generate the answer
        # print("\nSources Used:")
        # for source in result["source_documents"]:
        #     print(f"- Page {source.metadata.get('page', 'N/A')}: \"{source.page_content[:100]}...\"")

if __name__ == "__main__":
    main()